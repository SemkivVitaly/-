using NUnit.Framework;
using WSUniversalLib;

namespace NUnitTestWSUniversalLib
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void TestCalculateMaterialResult()
        {
            int count = 10;
            int width = 2;
            int length = 3;
            int productType = 2;
            int materialType = 2;
            int expected = 150;

            int result = MaterialCalculator.CalculateMaterial(count, width, length, productType, materialType);

            Assert.AreEqual(expected, result);
        }

        [Test]
        public void TestCalculateMaterialResultInvalidProductType()
        {
            int count = 10;
            int width = 2;
            int length = 3;
            int productType = 4;
            int materialType = 2;
            int expected = -1;

            int result = MaterialCalculator.CalculateMaterial(count, width, length, productType, materialType);

            Assert.AreEqual(expected, result);
        }

        [Test]
        public void TestCalculateMaterialResultInvalidMaterialType()
        {
            int count = 10;
            int width = 2;
            int length = 3;
            int productType = 2;
            int materialType = 3;
            int expected = -1;

            int result = MaterialCalculator.CalculateMaterial(count, width, length, productType, materialType);

            Assert.AreEqual(expected, result);
        }

        [Test]
        public void TestGetProductTypeFactorProductType1()
        {
            int productType = 1;
            double expected = 1.1;

            double result = MaterialCalculator.GetProductTypeFactor(productType);

            Assert.AreEqual(expected, result);
        }

        [Test]
        public void TestGetProductTypeFactorProductType2()
        {
            int productType = 2;
            double expected = 2.5;

            double result = MaterialCalculator.GetProductTypeFactor(productType);

            Assert.AreEqual(expected, result);
        }

        [Test]
        public void TestGetProductTypeFactorProductType3()
        {
            int productType = 3;
            double expected = 8.43;

            double result = MaterialCalculator.GetProductTypeFactor(productType);

            Assert.AreEqual(expected, result);
        }

        [Test]
        public void TestGetProductTypeFactorInvalidProductType()
        {
            int productType = 4;
            double expected = 0;

            double result = MaterialCalculator.GetProductTypeFactor(productType);

            Assert.AreEqual(expected, result);
        }

        [Test]
        public void TestGetMaterialTypeFactorMaterialType1()
        {
            int materialType = 1;
            double expected = 0.003;

            double result = MaterialCalculator.GetMaterialTypeFactor(materialType);

            Assert.AreEqual(expected, result);
        }

        [Test]
        public void TestGetMaterialTypeFactorMaterialType2()
        {
            int materialType = 2;
            double expected = 0.0012;

            double result = MaterialCalculator.GetMaterialTypeFactor(materialType);

            Assert.AreEqual(expected, result);
        }

        [Test]
        public void TestGetMaterialTypeFactorInvalidMaterialType()
        {
            int materialType = 3;
            double expected = 0;


            double result = MaterialCalculator.GetMaterialTypeFactor(materialType);


            Assert.AreEqual(expected, result);
        }
    }
}