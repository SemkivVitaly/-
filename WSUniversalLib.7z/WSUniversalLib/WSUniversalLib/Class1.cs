﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WSUniversalLib
{
    public class MaterialCalculator
    {
        // Method to calculate the amount of material needed for producing a certain amount of product
        public static int CalculateMaterial(int count, float width, float length, int productType, int materialType)
        {
            int material = 0;


            // Check if valid product and material type
            if (productType > 0 && productType < 4 && materialType > 0 && materialType < 3 && count >= 0 && width >= 0.1 && length >= 0.1)
            {
                // Calculate the amount of material
                material = (int)Math.Ceiling((count * width * length * GetProductTypeFactor(productType) * (1 + GetMaterialTypeFactor(materialType))));
            }
            else
            {
                // Return -1 if product or material type invalid
                return -1;
            }

            return material;
        }

        // Method to get the factor for the product type
        public static double GetProductTypeFactor(int productType)
        {
            switch (productType)
            {
                case 1:
                    return 1.1;
                case 2:
                    return 2.5;
                case 3:
                    return 8.43;
                default:
                    return 0;
            }
        }

        // Method to get the factor for the material type
        public static double GetMaterialTypeFactor(int materialType)
        {
            switch (materialType)
            {
                case 1:
                    return 0.003;
                case 2:
                    return 0.0012;
                default:
                    return 0;
            }
        }
    }

}

